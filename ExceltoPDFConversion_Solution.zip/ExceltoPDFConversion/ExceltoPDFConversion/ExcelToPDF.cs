﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Activities;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;

namespace ExceltoPDFConversion
{
    public class ExcelToPDF : CodeActivity
    {

        [Category("Input")]
        [RequiredArgument]
        public InArgument<string> ExcelSourcePath { get; set; }

        [Category("Input")]
        public InArgument<string> DestinationPath { get; set; }

        [Category("Input")]
        public InArgument<string> SheetName { get; set; }

        [Category("Output")]
        public OutArgument<bool> Output { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            string excelSourcePath = ExcelSourcePath.Get(context);
            string destinationPath = DestinationPath.Get(context);
            string sheetName = SheetName.Get(context);
            bool result = false;
            Microsoft.Office.Interop.Excel.Application excel;
            Workbook workbook;
            Worksheet worksheet;
            try
            {
                excel = new ApplicationClass(); // creates the instance of Excel Workbook
                workbook = excel.Workbooks.Open(excelSourcePath); //Open the particular excel file
                excel.Visible = false;
                if (destinationPath != null)
                {
                    
                    if (result == false && sheetName != null)
                    {
                        worksheet = (Worksheet)excel.Worksheets[sheetName]; //Select a Sheet by specifying the worksheet name
                        worksheet.Activate(); //Activates the particular worksheet
                        worksheet.ExportAsFixedFormat(0, destinationPath); //converts excel to PDF format, type specifies the output format to which excel is converted, for PDF the value is 0
                        result = true;
                    }
                    if (result == false && sheetName == null)
                    {
                        workbook.ExportAsFixedFormat(0, destinationPath);
                        result = true;
                    }
                }
                else
                {
                    destinationPath = excelSourcePath.Substring(0, excelSourcePath.LastIndexOf('.'));
                    
                    if (result == false && sheetName != null)
                    {
                        worksheet = (Worksheet)excel.Worksheets[sheetName]; //Select a Sheet by specifying the worksheet name
                        worksheet.Activate(); //Activates the particular worksheet
                        worksheet.ExportAsFixedFormat(0, destinationPath); //converts excel to PDF format, type specifies the output format to which excel is converted, for PDF the value is 0
                        result = true;
                    }
                    if (result == false && sheetName == null)
                    {
                        workbook.ExportAsFixedFormat(0, destinationPath);
                        result = true;
                    }
                }
                workbook.Close(); //Closing the Workbook
                
                excel.Quit();
                Output.Set(context, result);
                


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                Console.WriteLine(ex.Message);
                
            }
        }
    }
}
